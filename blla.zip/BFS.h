//
// Created by omer on 17/01/2020.
//

#ifndef ADVPROG_MILESTONE2_BFS_H
#define ADVPROG_MILESTONE2_BFS_H
#include "Searcher.h"
#include <vector>
#include <list>
template <typename T, typename S>
class BFS: public Searcher<T, S>{
    vector<State<T>*> visited;
public:
    S search(Searchable<T> *s){
        // Create a queue for BFS
        list<State<T>*> queue;

        // Mark the current node as visited and enqueue it
        visited.push_back(s->getInitialState());
        queue.push_back(s->getInitialState());

        // 'i' will be used to get all adjacent
        // vertices of a vertex
        while(!queue.empty())
        {
            // Dequeue a vertex from queue and print it
            State<T>* p  = queue.front();
            //cout << s << " ";
            queue.pop_front();
            vector<State<T>*> adjList = s->getAllPossibleStates(p);
            // Get all adjacent vertices of the dequeued
            // vertex s. If a adjacent has not been visited,
            // then mark it visited and enqueue it
            for(State<T>* i :adjList) {
                //if (!count(visited.begin(), visited.end(), i) && i->getCost() != -1) {
                if (contains(i) && i->getCost() != -1) {
                    visited.push_back(i);
                    queue.push_back(i);
                    i->setPrevious(p);
                }
                if (s->isGoalState(i)) {
                    return visited;
                }
            }
        }
    }
    bool contains(State<T> *s) {
        for (State<T> *s1 : visited) {
            if (s == s1) {
                return true;
            }
        }
        return false;
    }
};


#endif //ADVPROG_MILESTONE2_BFS_H
